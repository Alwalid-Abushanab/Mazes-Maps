public class DriverP1 {
    public static void main(String[] args) {
        Room room = new Room("A");
        room.setEastLock("RED");
        room.setEastRoom(new Room("E"));
        room.setNorthRoom(new Room("N"));
        room.setWestRoom(new Room("W"));
        room.setSouthRoom(new Room("S"));

        System.out.println("The following movements can be performed from room " + room.name());
        for (Action action: room) {
            String key = "without a key.";
            if (!action.key.equals("")){
                key = "with a " + action.key + " key.";
            }

            System.out.printf("Using the %s gate we can access room %s %s\n",
                    action.gate, action.room.name(), key);

        }
    }
}
