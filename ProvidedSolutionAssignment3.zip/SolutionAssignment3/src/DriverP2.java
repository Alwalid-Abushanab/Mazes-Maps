public class DriverP2 {
    public static void main(String[] args) {
        BidirectionalMap myMap = new BidirectionalMap("maze.txt");
        myMap.mazeReport();
    }
}
